public class customer_all {
}
